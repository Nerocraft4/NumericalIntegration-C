#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rungekuta.h"

int main(int, char *);
